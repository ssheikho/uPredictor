
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import random
import sys

from create_numbers_class import *
from windowtitle_class import *
from create_pictures_class import *

class Firstwindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Caris Lab - University of British Columbia")
        self.create_layout()
        self.i = 0


    def create_layout(self):
        #Add widgets
        self.internal_window_title = Windowtitle("CARIS LAB")
        self.numbers = Create_numbers()
        self.pictures = Create_pictures()
        self.button_new = QPushButton("New")

        # create layout to hold widgets
        self.initial_layout = QVBoxLayout()
        self.initial_layout.addWidget(self.internal_window_title)
        self.initial_layout.addWidget(self.numbers)
        self.initial_layout.addWidget(self.pictures)
        self.initial_layout.addWidget(self.button_new)

        self.select_widget = QWidget()
        self.select_widget.setLayout(self.initial_layout)

        self.setCentralWidget(self.select_widget)

        self.button_new.clicked.connect(self.button_press)

    def button_press(self):
        self.pictures.methods2(self.i)
        self.numbers.methods(self.i)
        self.i = self.i + 1
        print(self.i)
        if self.i == 20:
            self.button_new.setEnabled(False)
            QMessageBox.about(self,"Sets concluded", "20 combinations concluded")






def main():
    simulation = QApplication(sys.argv)
    window = Firstwindow()
    window.show()
    window.raise_()
    simulation.exec_()

if __name__ == "__main__":
    main()